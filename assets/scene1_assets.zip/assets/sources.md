# Sources

[Super Mario Tileset](http://rmrk.net/index.php?topic=37002.0) by Arrow
[Tuxemon](https://github.com/Tuxemon/Tuxemon) tileset, sprites and level by the Tuxemon team
[Cat Astro Phi](http://www.photonstorm.com/games/cat-astro-phi) tileset and level by Rich Davey & Ilija Melentijević 